rm -rf HTTP TCP invalid-ips.txt log.txt 
sleep 5
python run-traceroutes-webservers.py resolved.txt

