#echo "I am in this directory."
#pwd
#echo 'just deleted old directory'
cd /root/temp_country
cd step5_run_in_us
echo 'spoofing script about to start'
python spoof.py
echo 'all spoofed packets sent'
