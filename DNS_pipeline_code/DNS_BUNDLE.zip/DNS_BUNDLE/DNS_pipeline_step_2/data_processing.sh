python shoaib_parse_spoof_pcap.py
python ./step4_traceroute/shoaib_analyze_traceroute.py 
sshpass -p "&AYB&&D#H8#@" scp -o StrictHostKeyChecking=no root@108.62.49.40:/root/GLOBAL_MDA_DNS_LOGS/final_log .

