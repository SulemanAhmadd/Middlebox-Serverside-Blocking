Ronaldo.sh is the script which is supposed to collect data. To start data 
collection, run "bash ronaldo.sh".

Please note that before starting this bundle, place a 
"have_auth_no_ip_extended.common_three_runs.txt" file in 
step3_resolve_again_get_ns folder.
