Run "bash ronaldo.sh" to start receiving spoofed packets.
