tr -d '\000' < MDA_DNS_scamper_output.txt > MDA_DNS_scamper_output_temp.txt
